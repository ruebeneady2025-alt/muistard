package com.mustard.addon;

import com.mustard.addon.modules.AdvancedBlockESP;
import com.mustard.addon.modules.AdvancedItemESP;
import com.mustard.addon.modules.AutoRTP;
import com.mustard.addon.gui.MustardGuiTheme;
import meteordevelopment.meteorclient.MeteorClient;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.gui.GuiThemes;
import meteordevelopment.orbit.EventHandler;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class Mustard extends MeteorAddon {
    public static final Logger LOG = LoggerFactory.getLogger("Mustard Client");
    public static final Category CATEGORY = new Category("Mustard Client");
    private boolean themeApplied;

    @Override
    public void onInitialize() {
        LOG.info("Mustard Client by yl8t loaded");
        // Replace Meteor's built-in theme with the dark mustard palette.
        MustardGuiTheme.install();
        Modules.get().add(new AdvancedItemESP());
        Modules.get().add(new AdvancedBlockESP());
        Modules.get().add(new AutoRTP());
        // Without this, onPostTick never fires and the palette is never applied.
        MeteorClient.EVENT_BUS.subscribe(this);
    }

    @EventHandler
    private void onPostTick(TickEvent.Post event) {
        if (themeApplied) return;
        if (GuiThemes.get() != null) {
            GuiThemes.select("Meteor");
            if (GuiThemes.get() instanceof MustardGuiTheme mustardTheme) mustardTheme.applyPalette();
            GuiThemes.save();
            themeApplied = true;
        }
    }

    @Override
    public void onRegisterCategories() {
        Modules.registerCategory(CATEGORY);
    }

    @Override
    public String getPackage() {
        return "com.mustard.addon";
    }
}
