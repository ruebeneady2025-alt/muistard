package com.mustard.addon.gui;

import meteordevelopment.meteorclient.gui.GuiThemes;
import meteordevelopment.meteorclient.gui.themes.meteor.MeteorGuiTheme;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;

/**
 * Mustard's replacement for Meteor's built-in theme. It keeps Meteor's native
 * widgets/layout, but changes the palette to a dark mustard/yellow theme.
 *
 * The theme deliberately keeps the same "Meteor" name so existing GUI
 * configuration continues to work and the built-in theme is replaced cleanly.
 */
public final class MustardGuiTheme extends MeteorGuiTheme {
    public MustardGuiTheme() {
        super();
        applyPalette();
    }

    public void applyPalette() {
        // Main mustard accent.
        accentColor.set(new SettingColor(218, 168, 28, 255));
        checkboxColor.set(new SettingColor(218, 168, 28, 255));
        favoriteColor.set(new SettingColor(235, 190, 45, 255));

        // Dark, warm background.
        setColor("background-color", new SettingColor(12, 10, 5, 235));
        setColor("hovered-background-color", new SettingColor(25, 21, 10, 245));
        setColor("pressed-background-color", new SettingColor(38, 31, 12, 255));
        setColor("module-background-color", new SettingColor(30, 25, 10, 255));

        // Warm outlines/separators.
        setColor("outline-color", new SettingColor(7, 6, 3, 255));
        setColor("hovered-outline-color", new SettingColor(55, 43, 12, 255));
        setColor("pressed-outline-color", new SettingColor(80, 62, 15, 255));
        setColor("separator-text-color", new SettingColor(225, 180, 40, 255));
        setColor("separator-center-color", new SettingColor(218, 168, 28, 255));
        setColor("separator-edges-color", new SettingColor(120, 95, 25, 170));

        // Text.
        textColor.set(new SettingColor(248, 242, 220, 255));
        textSecondaryColor.set(new SettingColor(180, 168, 130, 255));
        setColor("title-text-color", new SettingColor(255, 210, 65, 255));
        setColor("text-highlight-color", new SettingColor(218, 168, 28, 90));

        // Scrollbars/sliders use the same mustard accent.
        setColor("scrollbar-color", new SettingColor(35, 29, 12, 220));
        setColor("hovered-scrollbar-color", new SettingColor(55, 43, 12, 235));
        setColor("pressed-scrollbar-color", new SettingColor(75, 58, 15, 255));
        setColor("slider-handle-color", new SettingColor(218, 168, 28, 255));
        setColor("hovered-slider-handle-color", new SettingColor(235, 190, 45, 255));
        setColor("pressed-slider-handle-color", new SettingColor(255, 210, 65, 255));
        setColor("slider-left-color", new SettingColor(180, 135, 18, 255));
        setColor("slider-right-color", new SettingColor(35, 29, 12, 255));

        // Starscript gets a restrained warm palette too.
        setColor("starscript-text-color", new SettingColor(225, 215, 185, 255));
        setColor("starscript-braces-color", new SettingColor(170, 155, 110, 255));
        setColor("starscript-parenthesis-color", new SettingColor(205, 190, 145, 255));
        setColor("starscript-dots-color", new SettingColor(205, 190, 145, 255));
        setColor("starscript-commas-color", new SettingColor(205, 190, 145, 255));
        setColor("starscript-operators-color", new SettingColor(235, 190, 45, 255));
        setColor("starscript-strings-color", new SettingColor(180, 205, 110, 255));
        setColor("starscript-numbers-color", new SettingColor(225, 180, 80, 255));
        setColor("starscript-keywords-color", new SettingColor(255, 205, 90, 255));
        setColor("starscript-accessed-objects-color", new SettingColor(205, 175, 95, 255));
    }

    @SuppressWarnings("unchecked")
    private void setColor(String name, SettingColor color) {
        Setting<?> setting = settings.get(name);
        if (setting != null) {
            ((Setting<SettingColor>) setting).set(color);
        }
    }

    public static void install() {
        GuiThemes.add(new MustardGuiTheme());
    }
}
