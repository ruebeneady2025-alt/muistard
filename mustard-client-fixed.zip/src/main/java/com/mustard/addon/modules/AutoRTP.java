// Mustard Client - made by yl8t
// Repeatedly runs /rtp with a changeable delay, cycling through (or randomly picking) the DonutSMP regions.
// Stops by itself when you leave the world (disconnect, kick, or world change to the title screen).

package com.mustard.addon.modules;

import com.mustard.addon.Mustard;
import meteordevelopment.meteorclient.events.game.GameLeftEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.network.chat.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class AutoRTP extends Module {
    public enum Order {
        Cycle,
        Random
    }

    /** {display name, setting name, default command (shown with the leading slash)} */
    private static final String[][] REGIONS = {
            {"NA East", "na-east", "/rtp na east"},
            {"NA West", "na-west", "/rtp na west"},
            {"EU Central", "eu-central", "/rtp eu central"},
            {"EU West", "eu-west", "/rtp eu west"},
            {"Asia", "asia", "/rtp asia"},
            {"Oceania", "oceania", "/rtp oceania"}
    };

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgRegions = settings.createGroup("Regions");

    private final Setting<Order> order = sgGeneral.add(new EnumSetting.Builder<Order>()
            .name("region-order")
            .description("Cycle goes through the enabled regions in order. Random picks one each time.")
            .defaultValue(Order.Cycle)
            .build()
    );

    private final Setting<Integer> minInterval = sgGeneral.add(new IntSetting.Builder()
            .name("min-interval")
            .description("Shortest wait between RTPs, in seconds.")
            .defaultValue(30)
            .min(1)
            .sliderRange(1, 600)
            .build()
    );

    private final Setting<Integer> maxInterval = sgGeneral.add(new IntSetting.Builder()
            .name("max-interval")
            .description("Longest wait between RTPs, in seconds. Set equal to min-interval for a fixed delay.")
            .defaultValue(60)
            .min(1)
            .sliderRange(1, 600)
            .build()
    );

    private final Setting<Boolean> rtpOnEnable = sgGeneral.add(new BoolSetting.Builder()
            .name("rtp-on-enable")
            .description("Run the first RTP immediately when the module is turned on.")
            .defaultValue(true)
            .build()
    );

    private final Setting<Boolean> chatFeedback = sgGeneral.add(new BoolSetting.Builder()
            .name("chat-feedback")
            .description("Show each RTP and the delay until the next one in chat.")
            .defaultValue(true)
            .build()
    );

    private final List<Setting<Boolean>> enabled = new ArrayList<>();
    private final List<Setting<String>> commands = new ArrayList<>();

    private final Random random = new Random();
    private int ticksLeft;
    private int lastIndex = -1;

    public AutoRTP() {
        super(Mustard.CATEGORY, "AutoRTP", "Automatically runs /rtp on a timer, cycling through all DonutSMP regions. Stops when you disconnect.");

        for (String[] region : REGIONS) {
            Setting<Boolean> on = sgRegions.add(new BoolSetting.Builder()
                    .name(region[1])
                    .description("Include " + region[0] + " in the rotation.")
                    .defaultValue(true)
                    .build()
            );
            enabled.add(on);

            commands.add(sgRegions.add(new StringSetting.Builder()
                    .name(region[1] + "-command")
                    .description("Command sent for " + region[0] + ". Keep the leading / so the command can be pasted directly in chat.")
                    .defaultValue(region[2])
                    .visible(on::get)
                    .build()
            ));
        }
    }

    @Override
    public void onActivate() {
        lastIndex = -1;
        ticksLeft = rtpOnEnable.get() ? 0 : nextDelayTicks();
    }

    @Override
    public void onDeactivate() {
        ticksLeft = 0;
    }

    /** Fires when you leave the world: disconnect, kick, or quit to menu. */
    @EventHandler
    private void onGameLeft(GameLeftEvent event) {
        if (isActive()) toggle();
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        // Backup check: no world or no connection means we're not in a game any more.
        if (mc.level == null || mc.player == null || mc.getConnection() == null) {
            toggle();
            return;
        }

        if (ticksLeft > 0) {
            ticksLeft--;
            return;
        }

        int index = pickRegion();
        if (index < 0) {
            ChatUtils.sendMsg(Component.nullToEmpty("AutoRTP: no regions enabled, turning off."));
            toggle();
            return;
        }

        String command = commands.get(index).get().trim();
        if (command.startsWith("/")) command = command.substring(1);
        lastIndex = index;
        ticksLeft = nextDelayTicks();

        if (command.isEmpty()) return;
        mc.getConnection().sendCommand(command);

        if (chatFeedback.get()) {
            ChatUtils.sendMsg(Component.nullToEmpty("AutoRTP: " + REGIONS[index][0] + " (/" + command + "), next in " + (ticksLeft / 20) + "s"));
        }
    }

    private int pickRegion() {
        List<Integer> options = new ArrayList<>();
        for (int i = 0; i < REGIONS.length; i++) {
            if (enabled.get(i).get()) options.add(i);
        }
        if (options.isEmpty()) return -1;

        if (order.get() == Order.Random) {
            return options.get(random.nextInt(options.size()));
        }

        for (int step = 1; step <= REGIONS.length; step++) {
            int i = (lastIndex + step) % REGIONS.length;
            if (enabled.get(i).get()) return i;
        }
        return options.get(0);
    }

    private int nextDelayTicks() {
        int lo = Math.min(minInterval.get(), maxInterval.get());
        int hi = Math.max(minInterval.get(), maxInterval.get());
        int seconds = lo + random.nextInt(hi - lo + 1);
        return seconds * 20;
    }

    @Override
    public String getInfoString() {
        return (ticksLeft / 20) + "s";
    }
}
