// Mustard Client - made by yl8t
// Cached block ESP based on Meteor's chunk/update model. No repeated radius scans.
package com.mustard.addon.modules;

import com.mustard.addon.Mustard;
import com.mustard.addon.util.DetectionLog;
import it.unimi.dsi.fastutil.longs.Long2ObjectOpenHashMap;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.BlockUpdateEvent;
import meteordevelopment.meteorclient.events.world.ChunkDataEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.Utils;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.meteorclient.utils.render.RenderUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.core.BlockPos;
import net.minecraft.network.DisconnectionDetails;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.chunk.ChunkAccess;
import net.minecraft.world.level.levelgen.Heightmap;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class AdvancedBlockESP extends Module {
    private static final int MAX_CHAT_PER_UPDATE = 5;

    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgAlerts = settings.createGroup("Alerts");
    private final SettingGroup sgRender = settings.createGroup("Render");

    private final Setting<List<Block>> blocks = sgGeneral.add(new BlockListSetting.Builder()
            .name("blocks")
            .description("Blocks to highlight in loaded chunks.")
            .defaultValue(new ArrayList<>(List.of(Blocks.ANCIENT_DEBRIS)))
            .build());

    private final Setting<Integer> maxBlocks = sgGeneral.add(new IntSetting.Builder()
            .name("max-blocks")
            .description("Maximum number of matching blocks rendered at once.")
            .defaultValue(2000)
            .min(1)
            .sliderRange(100, 10000)
            .build());

    private final Setting<Boolean> chatFeedback = sgAlerts.add(new BoolSetting.Builder()
            .name("chat-feedback")
            .description("Display newly found blocks in chat.")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> coordsInChat = sgAlerts.add(new BoolSetting.Builder()
            .name("coords-in-chat")
            .description("Include coordinates in the chat message.")
            .defaultValue(true)
            .visible(chatFeedback::get)
            .build());

    private final Setting<Boolean> logToFile = sgAlerts.add(new BoolSetting.Builder()
            .name("log-to-file")
            .description("Write newly found blocks to mustard-client/detections.log.")
            .defaultValue(true)
            .build());

    private final Setting<Boolean> disconnectOnFound = sgAlerts.add(new BoolSetting.Builder()
            .name("disconnect-on-found")
            .description("Disconnect when a matching block is found.")
            .defaultValue(false)
            .build());

    private final Setting<Boolean> disableDisconnectAfterFound = sgAlerts.add(new BoolSetting.Builder()
            .name("disable-disconnect-after-found")
            .description("After disconnecting once, disable only the disconnect action. ESP stays active.")
            .defaultValue(true)
            .visible(disconnectOnFound::get)
            .build());

    private final Setting<ShapeMode> shapeMode = sgRender.add(new EnumSetting.Builder<ShapeMode>()
            .name("shape-mode")
            .description("How matching blocks are rendered.")
            .defaultValue(ShapeMode.Lines)
            .build());

    private final Setting<SettingColor> lineColor = sgRender.add(new ColorSetting.Builder()
            .name("line-color")
            .description("Outline color.")
            .defaultValue(new SettingColor(230, 190, 20, 255))
            .build());

    private final Setting<SettingColor> sideColor = sgRender.add(new ColorSetting.Builder()
            .name("side-color")
            .description("Fill color.")
            .defaultValue(new SettingColor(230, 190, 20, 45))
            .build());

    private final Setting<Boolean> tracers = sgRender.add(new BoolSetting.Builder()
            .name("tracers")
            .description("Draw a tracer to matching blocks.")
            .defaultValue(false)
            .build());

    private final Setting<SettingColor> tracerColor = sgRender.add(new ColorSetting.Builder()
            .name("tracer-color")
            .description("Tracer color.")
            .defaultValue(new SettingColor(230, 190, 20, 255))
            .visible(tracers::get)
            .build());

    private final Long2ObjectOpenHashMap<Set<Long>> chunkBlocks = new Long2ObjectOpenHashMap<>();
    private final ExecutorService worker = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "Mustard-BlockESP");
        t.setDaemon(true);
        return t;
    });
    // Touched from the worker thread and the main thread.
    private final Set<Long> alerted = ConcurrentHashMap.newKeySet();
    private volatile boolean disconnectArmed;
    private Object lastLevel;

    public AdvancedBlockESP() {
        super(Mustard.CATEGORY, "AdvancedBlockESP", "Cached Meteor-style block ESP with chat logging and optional disconnect-on-found.");
    }

    @Override
    public void onActivate() {
        synchronized (chunkBlocks) {
            chunkBlocks.clear();
        }
        alerted.clear();
        disconnectArmed = true;
        lastLevel = mc.level;
        if (mc.level != null) {
            for (ChunkAccess chunk : Utils.chunks()) searchChunk(chunk);
        }
    }

    @Override
    public void onDeactivate() {
        synchronized (chunkBlocks) {
            chunkBlocks.clear();
        }
        alerted.clear();
    }

    private boolean wanted(Block block) {
        return blocks.get().contains(block);
    }

    private void searchChunk(ChunkAccess chunk) {
        // The expensive chunk search is done off the render/tick thread.
        worker.submit(() -> {
            if (!isActive() || mc.level == null) return;
            long key = chunk.getPos().pack();
            Set<Long> matches = new HashSet<>();
            BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();

            int minY = mc.level.getMinY();
            Heightmap heightmap = chunk.getOrCreateHeightmapUnprimed(Heightmap.Types.WORLD_SURFACE);
            for (int x = chunk.getPos().getMinBlockX(); x <= chunk.getPos().getMaxBlockX(); x++) {
                for (int z = chunk.getPos().getMinBlockZ(); z <= chunk.getPos().getMaxBlockZ(); z++) {
                    int height = heightmap.getFirstAvailable(x - chunk.getPos().getMinBlockX(), z - chunk.getPos().getMinBlockZ());
                    for (int y = minY; y < height; y++) {
                        pos.set(x, y, z);
                        if (wanted(chunk.getBlockState(pos).getBlock())) matches.add(pos.immutable().asLong());
                    }
                }
            }

            synchronized (chunkBlocks) {
                if (!isActive()) return;
                chunkBlocks.put(key, matches);
            }
            alertMatches(matches, true);
        });
    }

    /** Called from the worker thread: dedupes there, then does all game/chat work on the main thread. */
    private void alertMatches(Set<Long> matches, boolean disconnect) {
        if (!isActive() || matches.isEmpty()) return;
        List<Long> newMatches = new ArrayList<>();
        for (long packed : matches) if (alerted.add(packed)) newMatches.add(packed);
        if (newMatches.isEmpty()) return;

        mc.execute(() -> report(newMatches, disconnect));
    }

    private void report(List<Long> newMatches, boolean disconnect) {
        if (!isActive() || mc.level == null || mc.player == null) return;

        String playerPos = mc.player.getBlockX() + ", " + mc.player.getBlockY() + ", " + mc.player.getBlockZ();
        String firstSummary = null;
        int shown = 0;
        for (long packed : newMatches) {
            BlockPos p = BlockPos.of(packed);
            String name = mc.level.getBlockState(p).getBlock().getName().getString();
            String coords = p.getX() + ", " + p.getY() + ", " + p.getZ();
            if (firstSummary == null) firstSummary = name + " at " + coords;
            if (logToFile.get()) DetectionLog.write("AdvancedBlockESP", name + " at " + coords + " (player at " + playerPos + ")");
            if (chatFeedback.get() && shown++ < MAX_CHAT_PER_UPDATE) {
                String msg = name + " found" + (coordsInChat.get() ? " at " + coords : "");
                ChatUtils.sendMsg(Component.nullToEmpty(msg));
            }
        }
        if (chatFeedback.get() && newMatches.size() > MAX_CHAT_PER_UPDATE) {
            ChatUtils.sendMsg(Component.nullToEmpty("...and " + (newMatches.size() - MAX_CHAT_PER_UPDATE) + " more"));
        }

        if (disconnect && disconnectArmed && disconnectOnFound.get() && mc.getConnection() != null) {
            if (disableDisconnectAfterFound.get()) disconnectArmed = false;
            mc.getConnection().getConnection().disconnect(new DisconnectionDetails(
                    Component.literal("[AdvancedBlockESP] Found: " + firstSummary)));
        }
    }

    @EventHandler
    private void onChunkData(ChunkDataEvent event) {
        searchChunk(event.chunk());
    }

    @EventHandler
    private void onBlockUpdate(BlockUpdateEvent event) {
        int x = event.pos.getX();
        int y = event.pos.getY();
        int z = event.pos.getZ();
        long key = ChunkPos.pack(x >> 4, z >> 4);
        // The event object is pooled/reused, so copy what we need before going async.
        Block newBlock = event.newState.getBlock();
        Block oldBlock = event.oldState.getBlock();

        worker.submit(() -> {
            if (!isActive() || mc.level == null) return;
            boolean added = wanted(newBlock) && !wanted(oldBlock);
            boolean removed = !wanted(newBlock) && wanted(oldBlock);
            if (!added && !removed) return;

            synchronized (chunkBlocks) {
                Set<Long> matches = chunkBlocks.computeIfAbsent(key, ignored -> new HashSet<>());
                long packed = BlockPos.asLong(x, y, z);
                if (added) matches.add(packed);
                else matches.remove(packed);
            }

            if (added) {
                Set<Long> one = new HashSet<>();
                one.add(BlockPos.asLong(x, y, z));
                alertMatches(one, true);
            } else {
                alerted.remove(BlockPos.asLong(x, y, z));
            }
        });
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.level == null || mc.player == null) return;
        if (mc.level != lastLevel) {
            lastLevel = mc.level;
            onActivate();
        }
        // Forget cached chunks that are no longer near the player/render distance.
        synchronized (chunkBlocks) {
            int view = Utils.getRenderDistance() + 2;
            int cx = mc.player.blockPosition().getX() >> 4;
            int cz = mc.player.blockPosition().getZ() >> 4;
            chunkBlocks.long2ObjectEntrySet().removeIf(entry -> {
                ChunkPos pos = new ChunkPos(entry.getLongKey());
                return Math.abs(pos.x - cx) > view || Math.abs(pos.z - cz) > view;
            });
        }
    }

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (mc.level == null || mc.player == null) return;
        int rendered = 0;
        synchronized (chunkBlocks) {
            outer:
            for (Set<Long> matches : chunkBlocks.values()) {
                for (long packed : matches) {
                    if (rendered++ >= maxBlocks.get()) break outer;
                    BlockPos p = BlockPos.of(packed);
                    if (!wanted(mc.level.getBlockState(p).getBlock())) continue;
                    double x = p.getX();
                    double y = p.getY();
                    double z = p.getZ();
                    event.renderer.box(x, y, z, x + 1, y + 1, z + 1,
                            sideColor.get(), lineColor.get(), shapeMode.get(), 0);
                    if (tracers.get()) {
                        event.renderer.line(RenderUtils.center.x, RenderUtils.center.y, RenderUtils.center.z,
                                x + 0.5, y + 0.5, z + 0.5, tracerColor.get());
                    }
                }
            }
        }
    }

    @Override
    public String getInfoString() {
        int count = 0;
        synchronized (chunkBlocks) {
            for (Set<Long> matches : chunkBlocks.values()) count += matches.size();
        }
        return Integer.toString(count);
    }
}
