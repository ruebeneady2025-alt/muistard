package com.mustard.addon.util;

import com.mustard.addon.Mustard;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/** Appends detections to <game folder>/mustard-client/detections.log */
public final class DetectionLog {
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    private DetectionLog() {}

    public static synchronized void write(String module, String message) {
        Mustard.LOG.info("[{}] {}", module, message);
        try {
            Path dir = FabricLoader.getInstance().getGameDir().resolve("mustard-client");
            Files.createDirectories(dir);
            String line = "[" + LocalDateTime.now().format(TIME) + "] [" + module + "] " + message + System.lineSeparator();
            Files.writeString(dir.resolve("detections.log"), line, StandardCharsets.UTF_8,
                    StandardOpenOption.CREATE, StandardOpenOption.APPEND);
        } catch (IOException e) {
            Mustard.LOG.warn("Could not write detection log", e);
        }
    }
}
